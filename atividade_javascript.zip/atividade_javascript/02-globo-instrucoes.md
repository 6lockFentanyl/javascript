# Exercício 2 — Alterações no DevTools do Globo.com

Este exercício deve ser feito no navegador, pois o screenshot precisa mostrar a página real do Globo.com com as alterações temporárias.

1. Acesse https://www.globo.com/.
2. Abra as ferramentas de desenvolvedor com `F12` ou `Ctrl + Shift + I` e selecione **Console**.
3. Para trocar o título, execute o comando abaixo, substituindo o texto pelo título de uma notícia que você gostaria que acontecesse:

```js
document.querySelector('.post__title').textContent = 'Cientistas anunciam uma descoberta que vai salvar milhares de vidas'
```

Se `document.querySelector('.post__title')` retornar `null`, o elemento da página pode usar outra classe ou não estar disponível na página carregada. Nesse caso, inspecione o título desejado na guia **Elements/Elementos** e use o seletor correto.

4. Para alterar a imagem, abra **Elements/Elementos**, selecione a imagem da notícia e, no Console, use uma referência à imagem selecionada (`$0`). Exemplo:

```js
$0.srcset = 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?w=1200'
$0.src = 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?w=1200'
```

A imagem de exemplo pode ser substituída por outra imagem pública na web. Se o navegador não atualizar a imagem, verifique se selecionou a tag `<img>` correta. Algumas páginas usam imagens de fundo ou carregamento dinâmico.

5. Tire um screenshot com as alterações visíveis e cole-o na resposta/atividade. No Windows, use `Win + Shift + S` e selecione a área desejada.

**Observação:** as alterações feitas pelo Console são temporárias e normalmente desaparecem ao recarregar a página. Este arquivo registra os passos, mas não substitui o screenshot real que você precisa capturar no seu navegador.
