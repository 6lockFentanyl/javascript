# Atividade de JavaScript

Este projeto contém os arquivos dos exercícios 1 a 9.

## Como executar
- Abra os arquivos `.html` em um navegador.
- Os exercícios 3 a 9 funcionam localmente, sem servidor.
- O exercício 7 carrega imagens hospedadas na web, então precisa de conexão com a internet.
- O exercício 2 deve ser feito diretamente no site Globo.com usando o DevTools. Siga `02-globo-instrucoes.md` e capture seu próprio screenshot.

## Arquivos
1. `01-pesquisa-frontend.md` — pesquisa sobre JavaScript no frontend.
2. `02-globo-instrucoes.md` — passos do DevTools e screenshot.
3. `03-alterar-h1.html` — altera texto, cor e tamanho aleatório de um H1.
4. `04-contador.html` — contador com incrementar e zerar.
5. `05-lista-dinamica.html` — adiciona itens com `createElement()` e `appendChild()`.
6. `06-gerador-aventura.html` — gera nomes de aventura aleatórios.
7. `07-gravity-falls.html` — eventos do mouse e troca de personagem.
8. `08-sabor-sorvete.html` — identifica o texto digitado.
9. `09-modo-escuro.html` — exercício 8 com modo escuro.

As alterações do exercício 2 no site externo são temporárias e não ficam salvas neste projeto.
